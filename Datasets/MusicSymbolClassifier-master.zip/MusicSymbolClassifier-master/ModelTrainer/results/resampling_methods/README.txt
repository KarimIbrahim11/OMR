The different images have been created with the ImageResizer, using four different resampling methods:
1. Nearest Neighbor
2. Bicubic
3. Bilinear
4. Lanczos